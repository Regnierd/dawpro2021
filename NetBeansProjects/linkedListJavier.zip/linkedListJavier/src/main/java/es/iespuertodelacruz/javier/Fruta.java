package es.iespuertodelacruz.javier;

public class Fruta {

   String color;
   int peso;

   /**
    * Constructor de fruta
    * @param color de la fruta
    * @param peso de la fruta
    */
   public Fruta(String color, int peso) {
      this.color = color;
      this.peso = peso;
   }


   

   
}
