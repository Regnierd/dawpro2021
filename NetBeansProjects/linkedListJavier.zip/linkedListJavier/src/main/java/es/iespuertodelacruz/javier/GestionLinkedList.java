package es.iespuertodelacruz.javier;

import java.util.LinkedList;

import es.iespuertodelacruz.javier.excepcion.FrutaException;


public class GestionLinkedList {

    private static final String LA_LISTA_SE_ENCUENTRA_VACIA = "La lista se encuentra vacia";
    LinkedList<Fruta> lista;

    public GestionLinkedList() {
        lista = new LinkedList<>();
    }

    /**
     * Metodo que permite insertar al principio de la lista
     * @param fruta a insertar
     */
    public void insertarPrimera(Fruta fruta) {
        lista.addFirst(fruta);
    }

     /**
     * Metodo que permite insertar al final de la lista
     * @param fruta a insertar
     */
    public void insertarUltimo(Fruta fruta) {
        lista.addLast(fruta);
    }

    /**
     * Metodo que permite eliminar al final de la lista
     * @param fruta a eliminar
     * @throws FrutaException controlada
     */
    public void eliminarUltimo() throws FrutaException {
        if (lista.isEmpty()) {
            throw new FrutaException(LA_LISTA_SE_ENCUENTRA_VACIA);
        }
        lista.removeLast();
    }

     /**
     * Metodo que permite eliminar al final de la lista
     * @param fruta a eliminar
     * @throws FrutaException controlada
     */
    public void eliminarPrimero() throws FrutaException {
        if (lista.isEmpty()) {
            throw new FrutaException(LA_LISTA_SE_ENCUENTRA_VACIA);
        }
        lista.removeFirst();
    }


}
