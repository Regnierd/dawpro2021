
package es.iespuertodelacruz.javier.exceptions;

/**
 *
 * @author Javi
 */
public class NumeroException extends Exception {

    public NumeroException() {
    }

    public NumeroException(String message) {
        super(message);
    }
    
}
