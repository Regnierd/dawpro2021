
package es.iespuertodelacruz.javier.exceptions;

/**
 *
 * @author Javi
 */
public class AsignaturaException extends Exception{

    public AsignaturaException() {
    }

    public AsignaturaException(String message) {
        super(message);
    }

    
    
}
